﻿using Exercise;

List<string> weatherUris= new List<string>()
{
    "https://eba9e180-1581-4fab-a933-5e354f521b0e.mock.pstmn.io/weather2", //Mock server in postman
    "https://eba9e180-1581-4fab-a933-5e354f521b0e.mock.pstmn.io/weather1"
};

var timeout = Task.Delay(10000); 
var weatherTasks = weatherUris.Select(Service.GetTemperatureAsync);

var temperatureRetrievalTask = GetTemperatureValueAsync(weatherTasks);

var completedTask = await Task.WhenAny(temperatureRetrievalTask, timeout);

if(completedTask==timeout)
{
    Console.WriteLine("Weather Stations could not return, timed out");
}
else
{
    var temperature = await temperatureRetrievalTask;
    Console.WriteLine($"Temperature is {temperature}");
}

static async Task<double?> GetTemperatureValueAsync(IEnumerable<Task<double?>> tasks)
{
    double? temperature = null;

    while(temperature==null)
    {
        var completedTask = await Task.WhenAny(tasks);
        temperature= await completedTask;
    }
    return temperature;
}
