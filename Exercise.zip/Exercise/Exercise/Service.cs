﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace Exercise
{
    internal static class Service
    {
        private static HttpClient _client = new HttpClient();

        public static async Task<double?> GetTemperatureAsync(string uri)
        {
            try
            {
                var httpResponse = await _client.GetAsync(uri);

                if(httpResponse == null || !httpResponse.IsSuccessStatusCode) 
                {
                    Console.WriteLine("Weather station is unavailable" + uri);
                    return null;
                }

                var weatherModel = await httpResponse.Content.ReadFromJsonAsync<WeatherModel>();

                return weatherModel?.Temperature;
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine("Weather stations down" + ex.Message);
                return null;
            }
            catch(Exception e)
            {
                Console.WriteLine("Weather stations down" + e.Message);
                return null;
            }
        }

    }

    record WeatherModel(double? Temperature);
}
